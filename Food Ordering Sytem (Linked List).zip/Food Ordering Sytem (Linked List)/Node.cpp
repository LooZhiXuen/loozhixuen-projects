#include "Node.h"
#include <iostream>

using namespace std;


Node::Node(){
	code = "";
	food = "";
	price = 0.0;
	next = NULL;
}

Node::Node(string c, string f, double p){
	code = c;
	food = f;
	price = p;
};
