#Chi Square of Independence
#H0: Score is independent with the continents
#H1: Score is dependent with the continents

library(readxl)
X2018 <- read_excel("2018.xlsx")
View(X2018)

library(MASS)
tbl= table(X2018$Continent,X2018$`Range Score`)
tbl

chisq.test(tbl,correct=FALSE)

alpha<-0.05
print(paste("The alpha value is: ",alpha))

x2.alpha <-qchisq(alpha, df=6,lower.tail=FALSE)
print(paste("The critical value is: ",x2.alpha))
