import java.util.*;

public class Restaurant_OS_Replacement_Algorithm{
    public static void main(String [] args){
        System.out.println("Welcome to RESTAURANT FOOD PREPARATION MANAGEMENT SYSTEM\n");
        Scanner sc = new Scanner (System.in);
        boolean quit = true;
        int frame_and_position_size = 0;
        int reference_string_size = 0;
        String reference_string_input;
        Vector <String> reference_string;
        Vector <Integer> compare_page_fault;
        int choice;
        
        System.out.print("Number of kitchen(s) in the restaurant: "); 
        frame_and_position_size = Integer.parseInt(sc.nextLine()); //insert size for frame
        
        while (quit == true){
            menu();
            choice = Integer.parseInt(sc.nextLine());
            reference_string = new Vector <String>();
            compare_page_fault = new Vector <Integer>();
            if (choice == 1){
                System.out.println("Food preparation for pre-order mode is chosen.");
                System.out.print("Number of order(s): ");
                reference_string_size = Integer.parseInt(sc.nextLine()); //insert size for reference string

                System.out.println();
                for (int i = 0; i<reference_string_size; i++){
                    System.out.print("Insert the customer's food orders: "); 
                    reference_string_input = sc.nextLine(); //insert input for reference string
                    reference_string.add(reference_string_input); //locate input into reference string
                }
                System.out.println();

                Vector <String> FIFO_reference_string = new Vector <String>(); //create reference string
                String [] FIFO_frame = new String [frame_and_position_size]; //create frame
                Arrays.fill(FIFO_frame, ""); //fill the frame with -1
                for (int i = 0; i<reference_string_size; i++){
                    FIFO_reference_string.add(reference_string.get(i)); //locate input into reference string
                }
                function1(reference_string_size, frame_and_position_size, FIFO_frame,FIFO_reference_string,compare_page_fault);
                    

                Vector <String> OPT_reference_string = new Vector <String>(); //create reference string
                String [] OPT_frame = new String [frame_and_position_size]; //create frame
                Arrays.fill(OPT_frame, ""); //fill the frame with -1
                int [] OPT_position = new int [frame_and_position_size]; //create position
                Arrays.fill(OPT_position, -1); //fill the position with -1
                for (int i = 0; i<reference_string_size; i++){
                    OPT_reference_string.add(reference_string.get(i)); //locate input into reference string
                }
                function2(reference_string_size, frame_and_position_size, OPT_frame,OPT_reference_string, OPT_position,compare_page_fault);

                int max = reference_string_size;
                int max_position = 0;
                for (int i = 0; i<compare_page_fault.size(); i++){
                    if (max>compare_page_fault.get(i)){
                        max = compare_page_fault.get(i);
                        max_position = i;
                    }
                }

                System.out.println("The least number for the workers need to replace the kitchen and apparatus from kitchen is: "+ max);

                if (max_position == 0){
                    System.out.println("Processing FIFO algorithm to get best food preparation scheduling..."+ "\n");
                    display_FIFO(reference_string_size, frame_and_position_size, FIFO_reference_string);
                }

                else if (max_position == 1){
                    System.out.println("Processing OPT algorithm to get best food preparation scheduling..."+ "\n");
                    display_OPT(reference_string_size, frame_and_position_size, FIFO_reference_string);
                }
            }
            else if (choice == 2){
                System.out.println("Food preparation for synchronize order mode is chosen.\n");
                String [] LRU_frame = new String [frame_and_position_size]; //create frame
                Arrays.fill(LRU_frame, ""); //fill the frame with -1
                int [] LRU_position = new int [frame_and_position_size]; //create position
                Arrays.fill(LRU_position, -1); //fill the position with -1 
                function3(frame_and_position_size, LRU_frame, LRU_position);
            }

            else{
                System.out.println("Exit the system");
                quit = false;
                sc.nextLine();
            }
        }
    }

    static void function1(int reference_string_size, int frame_and_position_size, String [] FIFO_frame, Vector<String>FIFO_reference_string,Vector<Integer>compare_page_fault){
        int FIFO_fault = 0, count = 0;
        for (int i = 0; i<reference_string_size; i++){
            boolean found = true;
            for (int j = 0; j<frame_and_position_size; j++){
                if (FIFO_frame[j].equals(FIFO_reference_string.get(i))){
                    found = false;
                    break;
                }  
            }
            if(found == true){
                FIFO_frame[count%frame_and_position_size]=FIFO_reference_string.get(i);
                count++;
                FIFO_fault++;
            }
        }
        compare_page_fault.add(FIFO_fault);
    }

    static void function2(int reference_string_size, int frame_and_position_size, String [] OPT_frame, Vector<String>OPT_reference_string, int [] OPT_position,Vector<Integer>compare_page_fault){
        boolean found = true;
        int count = 0, OPT_fault = 0, max = -1, biggest = -1;

        for (int i = 0; i<OPT_reference_string.size(); i++){
            found = true;
            biggest = -1;
            max = -1;

            for (int j = 0; j<frame_and_position_size; j++){ //trace the frame
                if (OPT_frame[j].equals(OPT_reference_string.get(i))){ //if the number is in the frame
                    found = false;
                    break;
                }
            }
            
            if (found == true){ // if the number is not in the frame
                for (int k = 0; k<frame_and_position_size; k++){
                    for (int j = (i+1); j<OPT_reference_string.size();j++){
                        if (OPT_frame[k].equals(OPT_reference_string.get(j)) && OPT_position[k]==-1){
                            // if inside frame got the future number, then it record the location of the future number
                            OPT_position[k] = j;
                        }
                    }
                }

                for (int k = 0; k<frame_and_position_size; k++){
                    if (OPT_position [k] == -1){
                        //if the position is -1 (means no future number, then assign the max as the replaced value)
                        max = k;
                        break;
                    }
                    else if (biggest<=OPT_position[k] && OPT_position[k]!=-1){
                        //if all the frame number got future number, find the biggest location for future number
                        biggest = OPT_position[k];
                        max = k;
                    }
                }
                Arrays.fill(OPT_position, -1);
                if (count<frame_and_position_size){
                    //This one when the frame is not fully filled
                    OPT_frame[count%frame_and_position_size] = OPT_reference_string.get(i);
                    count++;
                }

                else{
                    //This one when the frame is fully filled
                    OPT_frame[max]=OPT_reference_string.get(i);
                }

                OPT_reference_string.setElementAt("",i);
                OPT_fault++;
            }
        }
        compare_page_fault.add(OPT_fault);   
    }

    static void function3(int frame_and_position_size, String [] LRU_frame, int [] LRU_position){
        Scanner sc = new Scanner (System.in);
        Vector <String> LRU_reference_string = new Vector <String>(); //create reference string
        String  reference_string_input;
        String insert = "Y";
        boolean found;
        int biggest;
        int count = 0, LRT_fault = 0, max;
       
        do{
            System.out.print("Insert the customer's food orders: "); 
            reference_string_input = sc.nextLine(); //insert input for reference string
            LRU_reference_string.add(reference_string_input); //locate input into reference string
        
            int output_option = 0;
            String string_temp=""; //to store frame data for output
            int int_temp=0; // to store count data for output
            found = true;
            biggest = LRU_reference_string.size() + 1;
            max = -1;

            for (int j = 0; j<frame_and_position_size; j++){ //trace the frame
                if (LRU_frame[j].equals(reference_string_input)){ //if the number is in the frame
                    int_temp = j;
                    found = false;
                    break;
                }
            }
                
                if (found == true){ // if the number is not in the frame
                    for (int k = 0; k<frame_and_position_size; k++){
                        for (int j = 0; j<LRU_reference_string.size();j++){
                            if (LRU_frame[k].equals(LRU_reference_string.get(j))){
                                // if inside frame got the past number, then it record the location of the past number
                                LRU_position[k] = j;
                            }
                        }
                    }

                        
                    for (int k = 0; k<frame_and_position_size; k++){
                        if (LRU_position [k] == -1){
                            //if the position is -1 (means no past number, then assign the max as the replaced value)
                            max = k;
                            break;
                        }
                        else if (biggest>LRU_position[k]){
                            //if all the frame number got past number, find the smallest location for past number
                            biggest = LRU_position[k];
                            max = k;
                        }
                    }

                        if (count<frame_and_position_size){
                            output_option = 1;
                            int_temp = count%frame_and_position_size;
                            //This one when the frame is not fully filled
                            LRU_frame[count%frame_and_position_size] = reference_string_input;
                            count++;
                        }

                        else {
                            output_option = 2;
                            string_temp = LRU_frame[max];
                            int_temp = max;
                            //This one when the frame is fully filled
                            LRU_frame[max]=reference_string_input;
                        }

                        LRT_fault++;
                    }
                    for (int k = 0; k<frame_and_position_size; k++){
                        System.out.printf("%-20s", "Kitchen " + (k+1));
                    }
                    System.out.println();
        
                    for (int j = 0; j<frame_and_position_size; j++){
                        System.out.printf("%-20s", LRU_frame[j]);
                    }
    
                    if (output_option == 0){
                        System.out.println("No replacement is needed, " + reference_string_input + " is at Kitchen " + (int_temp+1));
                    }
        
                    else if (output_option == 1){
                        System.out.println("Setup " + reference_string_input + " at Kitchen "+ (int_temp+1));
                    }
        
                    else if (output_option == 2){
                        System.out.println(string_temp + " --> " + reference_string_input + " at Kitchen "+ (int_temp+1));
                    }
                    System.out.println();
                    
        System.out.print("Do you want to insert another customer order? Y for Yes and N for No: ");
        insert = sc.nextLine();
        }
        while (insert.equals("Y"));
        System.out.println("The least number for the workers need to replace the ingredients and apparatus from kitchen is: "+ LRT_fault);
    }

    static void display_FIFO(int reference_string_size, int frame_and_position_size, Vector<String>FIFO_reference_string){
        String [] FIFO_frame = new String [frame_and_position_size];
        Arrays.fill(FIFO_frame, "");
        int count = 0;
        for (int i = 0; i<reference_string_size; i++){
            int output_option = 0;
            String string_temp=""; //to store frame data for output
            int int_temp=0; // to store count data for output
            boolean found = true;
            for (int j = 0; j<frame_and_position_size; j++){
                if (FIFO_frame[j].equals(FIFO_reference_string.get(i))){
                    int_temp = j;
                    found = false;
                    break;
                }  
            }
            if(found == true){
                if (FIFO_frame[count%frame_and_position_size].equals("")){
                    output_option = 1;
                    int_temp = count%frame_and_position_size;
                }
                else{
                    output_option = 2;
                    string_temp = FIFO_frame[count%frame_and_position_size];
                    int_temp = count%frame_and_position_size;
                }
                FIFO_frame[count%frame_and_position_size]=FIFO_reference_string.get(i);
                count++;
            }

            for (int k = 0; k<frame_and_position_size; k++){
                System.out.printf("%-20s", "Kitchen " + (k+1));
            }
            System.out.println();

            for (int j = 0; j<frame_and_position_size; j++){
                System.out.printf("%-20s", FIFO_frame[j]);
            }

            if (output_option == 0){
                System.out.println("No replacement is needed, " + FIFO_reference_string.get(i) + " is at Kitchen " + (int_temp+1));
            }

            else if (output_option == 1){
                System.out.println("Setup " + FIFO_reference_string.get(i) + " at Kitchen "+ (int_temp+1));
            }

            else if (output_option == 2){
                System.out.println(string_temp + " --> " + FIFO_reference_string.get(i) + " at Kitchen "+ (int_temp+1));
            }
            System.out.println();

        }
    }

    static void display_OPT(int reference_string_size, int frame_and_position_size, Vector<String>OPT_reference_string){
        boolean found = true;
        int count = 0, max = -1, biggest = -1;
        String [] OPT_frame = new String [frame_and_position_size];
        Arrays.fill(OPT_frame, "");
        int [] OPT_position = new int [frame_and_position_size];
        Arrays.fill(OPT_position, -1);


        for (int i = 0; i<OPT_reference_string.size(); i++){
            int output_option = 0;
            String string_temp=""; //to store frame data for output
            int int_temp=0; // to store count data for output
            found = true;
            biggest = -1;
            max = -1;

            for (int j = 0; j<frame_and_position_size; j++){ //trace the frame
                if (OPT_frame[j].equals(OPT_reference_string.get(i))){ //if the number is in the frame
                    int_temp = j;
                    found = false;
                    break;
                }
            }
            
            if (found == true){ // if the number is not in the frame
                
                for (int k = 0; k<frame_and_position_size; k++){
                    for (int j = (i+1); j<OPT_reference_string.size();j++){
                        if (OPT_frame[k].equals(OPT_reference_string.get(j)) && OPT_position[k]==-1){
                            // if inside frame got the future number, then it record the location of the future number
                            OPT_position[k] = j;
                        }
                    }
                }

                
                for (int k = 0; k<frame_and_position_size; k++){
                    if (OPT_position [k] == -1){
                        //if the position is -1 (means no future number, then assign the max as the replaced value)
                        max = k;
                        break;
                    }
                    else if (biggest<=OPT_position[k] && OPT_position[k]!=-1){
                        //if all the frame number got future number, find the biggest location for future number
                        biggest = OPT_position[k];
                        max = k;
                    }
                }
                Arrays.fill(OPT_position, -1);

                if (count<frame_and_position_size){
                    output_option = 1;
                    int_temp = count%frame_and_position_size;
                    //This one when the frame is not fully filled
                    OPT_frame[count%frame_and_position_size] = OPT_reference_string.get(i);
                    count++;
                }

                else{
                    //This one when the frame is fully filled
                    output_option = 2;
                    string_temp = OPT_frame[max];
                    int_temp = max;
                    OPT_frame[max]=OPT_reference_string.get(i);
                }
            }

            for (int k = 0; k<frame_and_position_size; k++){
                System.out.printf("%-20s", "Kitchen " + (k+1));
            }
            System.out.println();

            for (int j = 0; j<frame_and_position_size; j++){
                System.out.printf("%-20s", OPT_frame[j]);
            }

            if (output_option == 0){
                System.out.println("No replacement is needed, " + OPT_reference_string.get(i) + " is at Kitchen " + (int_temp+1));
            }

            else if (output_option == 1){
                System.out.println("Setup " + OPT_reference_string.get(i) + " at Kitchen "+ (int_temp+1));
            }

            else if (output_option == 2){
                System.out.println(string_temp + " --> " + OPT_reference_string.get(i) + " at Kitchen "+ (int_temp+1));
            }
            System.out.println();
            OPT_reference_string.setElementAt("",i);
        }
    }

    static void menu(){
        System.out.println("\nPlease choose the order mode by the restaurant.");
        System.out.println("[1] Preorder");
        System.out.println("[2] Synchronize order");
        System.out.println("[3] Exit");
        System.out.print("\nPlease select pre-order mode or synchronize order mode: ");
    }
}