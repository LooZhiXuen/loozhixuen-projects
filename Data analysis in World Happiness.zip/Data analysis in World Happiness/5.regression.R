#regression

library(readxl)
asia <- read_excel("asia.xlsx")
View(asia)

x<-c(asia$`GDP per capita`)
y<-c(asia$`Score`)

plot(x,y,xlim=c(0,2.1),ylim=c(4,7),xlab="GDP per capita",ylab="Score")

abline(lm(y ~ x))
(lm(y ~ x))
summary(lm(y ~ x))
