#ifndef CUSTOMERLINKEDLIST_H
#define CUSTOMERLINKEDLIST_H
#include <iostream>
#include "Customer.h"
#include "Menulinkedlist.h"
using namespace std;

class Customerlinkedlist
{
	private:
		Customer *head;
		Customer *prev;
		Customer *curr;
		Customer *tail;
		
	public:
		Customerlinkedlist ();
		~Customerlinkedlist ();
		void addCustomer (string,string,Menulinkedlist *);
		void deleteCustomer (string);
		Customer * searchCustomerbytable (string);
		Customer * searchCustomerbyname (string);
		void listCustomer ();
		int getlistsize ();

};
#endif
