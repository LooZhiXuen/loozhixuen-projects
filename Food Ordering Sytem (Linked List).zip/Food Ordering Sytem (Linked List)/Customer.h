#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "Payment.h"
#include "Order.h"
#include "Item.h"
#include "Menulinkedlist.h"
#include <iostream>
using namespace std;

class Customer 
{
	

	public:
		string tableNo;
		string Name;
		Order order;
		Payment bill;
		Customer *next;
		Customer ();
		void printPaymentinfo ();
		void set (string, string);
		void PlaceOrder (Menulinkedlist *);
		void MakePayment ();	
};

#endif
