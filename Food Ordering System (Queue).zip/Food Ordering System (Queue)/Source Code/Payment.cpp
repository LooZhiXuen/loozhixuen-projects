#include "Payment.h"
#include <iostream>
#include <iomanip>
using namespace std;

Payment::Payment()
{
	cash=0;
	change=0;
	status=false;
	
}

void Payment::print()
{
	cout<<"Cash: "<<"RM "<<fixed<<setprecision(2)<<cash<<endl;
	cout<<"Change: "<<"RM "<<fixed<<setprecision(2)<<change<<endl;
}
bool Payment::getStatus ()
{
	return status;
}
double Payment::getCash()
{
	return cash;
}
double Payment::getChange()
{
	return change;
}
void Payment::set(double cash,double change)
{
	this->cash=cash;
	this->change=change;
	status=true;
	
}
