#include "Customer.h"
#include "Payment.h"
#include "Order.h"
#include "Item.h"
#include "MenuQueue.h"
#include "Node.h"
#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

Customer::Customer()
{
	tableNo="";
	Name="";
	next=NULL;
}

void Customer::printPaymentinfo ()
{
	cout<<left<<setw(20)<<tableNo<<setw(40)<<Name<<setw(20)<<order.getTotalPrice()<<setw(20)<<fixed<<setprecision(2)<<bill.getCash()<<setw(20)<<fixed<<setprecision(2)<<bill.getChange();
	if (bill.getStatus())
	{
		cout<<left<<setw(10)<<"Paid"<<endl;
	}
	else
	{
		cout<<left<<setw(10)<<"Unpay"<<endl;
	}
}
void Customer::set(string tn, string n)
{
	tableNo=tn;
	Name=n;
}

void Customer::PlaceOrder ( MenuQueue *menu)
{
	
			int itemquantity;
			string itemid,itemname;
			double itemprice;
				string tempid;
			int operation;
		
			
			do
			{
					cout<<"Choose the below operations"<<endl;
			cout<<"1. Add item into your order \n2. Remove item from your order \n3. Return to customer menu"<<endl;
			cout<<"Choice: ";
			cin>>operation;
			system("CLS");
			if (operation==1)
			{
	
			cout<<"Please place your order based on the menu"<<endl;
			menu->display();
			bool loop=true;
			int index=-1;
				tempid="OR"+tableNo+"/"+Name;
	
				cout<<endl<<"Your order ID: "<<tempid<<endl;
				order.setID(tempid);
			do
			{
			
				int pilihan;
				cin.ignore();
			Q:
				cout<<"Item ID: ";
				getline (cin,itemid);
				cout<<"Quantity: ";
				cin>>itemquantity;
				cin.ignore();	
				Node *tempnode;
				tempnode=menu->nodeExists(itemid);
				
				if (tempnode==NULL)
				{
					cout<<"Invalid Item ID...Please enter again"<<endl;
					goto Q;
				}
				
	
				order.AddItem(tempnode,itemquantity);
			E:
				cout<<"Do you wish to add another item into your order list? \n 1. Yes \n 2. No"<<endl;
				cout<<"Choice: ";
				cin>>pilihan;
				if (pilihan==1)
				{
					loop=true;
					
				}
				else if (pilihan==2)
				{
					loop=false;
				}
				else
				{
					cout<<"Invalid option...Please try again"<<endl;
					goto E;
				}
	
			}
			while (loop);
			system("CLS");
			order.print();
			
		}
		else if (operation==2)
		{
			if(order.getItemNo()==0)
			{
				cout<<"There is no item available to be removed from the order."<<endl;
		}
		else
		{
			
		
			cout<<"<<<<Removing items from the top to bottom of the order list<<<<<"<<endl;
		
			order.print();
			bool loop2=true;
			int index2;
			int pilihan;
			char removeoption;
			do
			{

				cout<<"Do you wish to remove the first item from the list?\nY=YES\nN=No\nChoice: ";
				cin>>removeoption;
				if (removeoption=='Y')
				{
					order.RemoveItem();
				}
	
				
			H:
				cout<<"Do you wish to remove another item into your order list? \n 1. Yes \n 2. No"<<endl;
				cout<<"Choice: ";
				cin>>pilihan;
				if (pilihan==1)
				{
					loop2=true;
					
				}
				else if (pilihan==2)
				{
					loop2=false;
				}
				else
				{
					cout<<"Invalid option...Please try again"<<endl;
					goto H;
				}
	
			}
			while (loop2);
			
			order.print();
		}
}
		else if (operation==3)
		{
			cout<<"The screen is returning to customer menu"<<endl;
			system("CLS");
		}
			}
			while (operation==1||operation==2);
		
}

void Customer::MakePayment ()
{
	if (!bill.getStatus()==false)// Checking whether the order has been made payment or not
	{
		cout<<endl<<"You have made payment for this order."<<endl;
	}
	else
	{
		
	
	double total=0,change,cash;
	cout<<endl<<"Order ID: "<<order.getOrderID()<<endl;
	cout<<"Total amount payable: RM "<<order.getTotalPrice()<<endl;
	cout<<"This machine can only receive \n1. RM 1\n2. RM 5\n3. RM 10\n4. RM 50\n5. RM 100 \nnotes"<<endl<<endl;

		do
		{
	
		cout<<"Note inserted: RM";
		cin>>cash;
		if (cash==1||cash==5||cash==10||cash==50||cash==100)
		{
			total=total+cash;
				cout<<"\nTotal amount inserted : RM"<<total<<endl;
		}
		else
		{
				cout<<"Invalid note inserted"<<endl;
		}

		}
		while ((cash!=1||cash!=5||cash!=10||cash!=50||cash!=100)&&(total<order.getTotalPrice()));

	change=total-order.getTotalPrice();
	bill.set(total, change);
	order.print();
	bill.print();
}
}
