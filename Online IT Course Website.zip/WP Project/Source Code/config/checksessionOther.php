<?php
require_once('function.php');
session_start();

if ((isset($_SESSION['userID']))){

    echo "<script>alert('Welcome back to the portal');</script>";

}


else
{

       goto2("../login.php","Please log in before using");

}


?>