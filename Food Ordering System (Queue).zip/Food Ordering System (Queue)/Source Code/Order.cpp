#include "Order.h"
#include "ItemQueue.h"
#include "Node.h"
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

Order::Order()
{
	orderId="";
	itemNo=0;
	itemOrdered=NULL;

}
void Order::setID(string id)
{
	orderId=id;
}
string Order::getOrderID()
{
	return orderId;
}
void Order::AddItem (Node * food, int quantity)
{
	if (itemOrdered==NULL)
	{
		itemOrdered=new ItemQueue ();
		itemOrdered->addItem_Queue(food,quantity);
	}
	else
	{
		itemOrdered->addItem_Queue(food,quantity);
	}
	itemNo++;
}

void Order::RemoveItem()
{

			if (itemNo==0)
			{
				cout<<"Invalid action !!!"<<endl;
				cout<<"There is no item added in this order."<<endl;
			}
			else// 
			{
			
				itemOrdered->deleteItem_Queue();
				itemNo--;
				
				
			}
}
int Order::getItemNo()
{
	return itemNo;
}

void Order::print ()
{
	cout<<endl<<endl<<"Order ID: "<<orderId<<endl;
	cout<<"Order List"<<endl;
	cout<<"----------"<<endl;
	cout<<left<<setw(10)<<"No"<<setw(20)<<"ID"<<setw(40)<<"Name"<<setw(20)<<"Unit Price/RM"<<setw(20)<<"Quantity"<<setw(20)<<"Total Price/RM"<<endl;
	itemOrdered->listitem();
	cout<<endl<<"Subtotal: RM"<<fixed<<setprecision(2)<<itemOrdered->getTotalItemPrice()<<endl<<endl;
}
double Order::getTotalPrice(){
	return itemOrdered->getTotalItemPrice();
}
