#ifndef ORDER_H
#define ORDER_H
#include "Itemlinkedlist.h"
#include "Node.h"

using namespace std;

class Order
{
	private:
	string orderId;
	int itemNo;
	Itemlinkedlist *itemOrdered;
	public:
		Order ();
		void setID (string);
		string getOrderID();
		int getItemNo ();
		void AddItem (Node *,int);
		void RemoveItem (string);
		void print ();
		double getTotalPrice ();
		
};

#endif
