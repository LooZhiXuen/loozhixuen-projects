import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
public class Cross_District_State_Application
{
	public static void displayApplicantMenu ()
	{
		System.out.println ("\n<<<< Applicant Interface >>>>>");
		System.out.println ("Please choose the following operations");
		System.out.println ("1) Make a cross-disctrict/state application ");
		System.out.println ("2) View your application status");
		System.out.println ("3) Return to previous interface");
		System.out.print("\nYour operation: ");
	}
	public static void displayStaffMenu ()
	{
				System.out.println ("\n<<<< Staff Interface >>>>>");
				System.out.println ("Please choose the following operations");
				System.out.println ("1) Process pending cross-district/state application during Movement Control Order (MCO) period");
				System.out.println ("2) View applications processed by you");
				System.out.println ("3) Return to previous interface");
				System.out.print("\nYour operation: ");
	}
	public static void main (String []args) throws IOException
	{
		Scanner input=new Scanner (System.in);
		System.out.println ("<<< Cross-District Or State Application System>>>");
		System.out.println ("\nBefore the program gets started, you need to initialize the staff first");
		System.out.println ("Please fill in the following information");



		ArrayList <Staff> sList=new ArrayList <Staff> ();

		String sName, sID,sPosition, sDepartment;
		String choice;
		do
		{
			System.out.print("\nStaff name: ");
			sName=input.nextLine();
			System.out.print("Staff ID: ");
			sID=input.nextLine();
			System.out.print("Staff Position: ");
			sPosition=input.nextLine();
			System.out.print("Staff Department: ");
			sDepartment=input.nextLine();
			Staff sTemp=new Staff (sName,sID,sPosition,sDepartment);
			sList.add(sTemp);
			do{
			System.out.println ("\nDo you still want to add new staff?\nPress Y if Yes\nPress N if No");
			System.out.print("Choice: ");
			choice=input.nextLine().toUpperCase();
			if (!choice.equals("Y")&&!choice.equals("N"))
			{
				System.out.println("Invalid input...Please enter again");
			}
			}
			while (!choice.equals("Y")&&!choice.equals("N"));
		}
		while (!choice.equals("N"));
		System.out.println("\n\n");
		//

		ArrayList <Application> appList= new ArrayList <Application> ();
		int optCategory=0,numCD=0,numCS=0;
		do
		{


			System.out.println("\nPlease select the following user category");
			System.out.println("1) Applicant");
			System.out.println("2) Staff");
			System.out.println("\nOr\n3) Terminate the program");
			// Exception handling 1
			boolean EH1=true;
			do{
			try{
			System.out.print("\nYour category: ");
			optCategory=Integer.parseInt(input.nextLine ());
			EH1=false;

			System.out.println("\n\n");
			}
			catch (Exception e)
			{
   			 System.out.println("Your input is not an Integer.Please try again");

			}
			}
			while(EH1);


			if (optCategory==1)
			{
				int optApplicant=0;
				do
				{
					boolean EH2;//Exception handling 2
					displayApplicantMenu();
					do{
						EH2=true;
					try{
					optApplicant=Integer.parseInt(input.nextLine());
					EH2=false;
					if (optApplicant!=1&&optApplicant!=2&&optApplicant!=3)
					{
						System.out.println("Invalid input...Please try again");
						System.out.print("\nYour operation: ");
					}
					}
					catch (Exception e)
					{
						System.out.println("Your input is not an Integer.Please try again");
						System.out.print("\nYour operation: ");

					}
					}
					while (EH2||(optApplicant!=1&&optApplicant!=2&&optApplicant!=3));

					if (optApplicant==1)
					{
						int optType=0;
						System.out.println ("\n\n<<< Make a cross district/state application >>>");
						System.out.println("Please select either one of the following types of application\n1) Cross-district application\n2) Cross-state application");
						do{

						boolean EH3=true;
						do{
							// Exception handling 3
							try{
						System.out.print("\nApplication type : ");
						optType=Integer.parseInt(input.nextLine ());

						System.out.println("\n");
						EH3=false;
							if (optType!=1&&optType!=2){
							System.out.println("Invalid input...Please try again");
							}
							}
							catch (Exception e){
								System.out.println("Your input is not an Integer.Please try again");
							}
						}
						while (EH3||(optType!=1&&optType!=2));
						String name,ic,gender,street,city,state,phone,email,occupation,app_date,app_time,t_no,dep_date,dep_time,purpose;
						int t_type;
						System.out.println("\nPlease fill in the following information ");
						System.out.print("\nName: ");
						name=input.nextLine();
						System.out.print("\nIC number: ");
						ic=input.nextLine();
						System.out.print("\nGender (M for Male/F for Female): ");
						gender=input.nextLine().toUpperCase();
						System.out.println("\n");
						System.out.println("\n<<< Address >>>");
						System.out.print("\t\tStreet: ");
						street=input.nextLine();
						System.out.print("\t\tCity: ");
						city=input.nextLine();
						System.out.print("\t\tState: ");
						state=input.nextLine();
						System.out.print("\nPhone number: ");
						phone=input.nextLine();
						System.out.print("\nEmail address: ");
						email=input.nextLine();
						System.out.print("\nOccupation: ");
						occupation=input.nextLine();

						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
						DateFormat timeFormat = new SimpleDateFormat("hh.mm aa");
						app_date = dateFormat.format(new Date()).toString();
						app_time = timeFormat.format(new Date()).toString();

						System.out.println("\n\n<<< Information of Application >>>");
						System.out.println("\nApplication date: "+app_date);

						System.out.println("Application Time: "+app_time);

						System.out.print("\nPurpose for making this application: ");
						purpose=input.nextLine();

						System.out.println("\n<<< Transportation type >>>");
						System.out.println("\t\t1) Personal vehicle");
						System.out.println("\t\t2) Public transport such as Bus and LRT");
						System.out.println("\t\t3) Flight");

						do
						{
						System.out.print ("\nTransportation type (1,2 or 3): ");
						t_type=Integer.parseInt(input.nextLine());
						if (!(t_type==1||t_type==2||t_type==3))
						{
							System.out.println("Invalid input...Please enter again");
						}
						}
						while (!(t_type==1||t_type==2||t_type==3));


						System.out.println("\nPlease enter the transportation number\nFor instance\n");

						System.out.println("1) Transportation number for personal vehicle=Vehicle's plate Number");
						System.out.println("2) Transportation number for public transport=Bus Number or LRT Number");
						System.out.println("3) Transportation number for flight=Flight Number");
						System.out.print("\nTransportation number: ");
						t_no=input.nextLine();
						System.out.println("\nPlease enter your departure date and time");
						System.out.print("\nDeparture date (DD/MM/YYYY): ");
						dep_date=input.nextLine();
						String AMPM;
						System.out.println("Departure time: ");
						do{
						System.out.print("\tPlease Enter am or pm: ");
						AMPM=input.nextLine().toLowerCase();
						}
						while (!AMPM.equals("am")&&!AMPM.equals("pm"));
						System.out.print("\tTime in Hour.Minute format: ");
						dep_time=input.nextLine();
						dep_time=dep_time+" "+AMPM;
						System.out.println("\n\n");
						Address alamat= new Address (street,city,state);
						Applicant person=new Applicant (name,ic,alamat,phone,email,occupation);
						person.setApplicant_gender(gender);

						if (optType==1)
						{
							String app_id;
							String app_state,ori_district,dest_district;
							System.out.println ("<<< Within State >>>");
							System.out.print("State: ");
							app_state=input.nextLine();
							System.out.print("Origin district: ");
							ori_district=input.nextLine();
							System.out.print("Destination district: ");
							dest_district=input.nextLine();
							numCD++;
							app_id="CD0"+Integer.toString(numCD);
							System.out.println ("\n\nYour application is submitted successfully");

							System.out.println ("\nYour application ID is "+app_id+"\n");
							Application cross_district=new Cross_district (app_id,app_date,app_time,purpose,app_state,ori_district,dest_district);
							cross_district.setApplicant(person);
							switch (t_type)
							{
								case 1: cross_district.setTransportation("Personal vehicle",t_no);
										break;
								case 2: cross_district.setTransportation("Public transport",t_no);
								break;
								case 3: cross_district.setTransportation("Flight",t_no);
								break;
							}

							cross_district.setDepartureDateTime(dep_date,dep_time);

							appList.add(cross_district);

						}
						else if (optType==2)
						{
							String app_id;
							String ori_state,ori_district,dest_state,dest_district;
							System.out.println ("<<< Cross State >>>");
							System.out.print("Origin State: ");
							ori_state=input.nextLine();
							System.out.print("Origin district: ");
							ori_district=input.nextLine();
							System.out.print("Destination State: ");
							dest_state=input.nextLine();
							System.out.print("Destination district: ");
							dest_district=input.nextLine();
							numCS++;
							app_id="CS0"+Integer.toString(numCS);
							System.out.println ("\n\nYour application is submitted successfully");
							System.out.println ("\nYour application ID is "+app_id+"\n");
							Application cross_state=new Cross_state (app_id,app_date,app_time,purpose,ori_state,ori_district,dest_state,dest_district);
							cross_state.setApplicant(person);
							switch (t_type)
							{
								case 1: cross_state.setTransportation("Personal vehicle",t_no);
										break;
								case 2: cross_state.setTransportation("Public transport",t_no);
								break;
								case 3: cross_state.setTransportation("Flight",t_no);
								break;
							}

							cross_state.setDepartureDateTime(dep_date,dep_time);

							appList.add(cross_state);



						}
						else
						{
							System.out.println("Invalid input...Please try again");

						}


						}while (!(optType==1||optType==2));
					}

					else if (optApplicant==2)
					{
						int optForView=0;

										do
										{
											System.out.println("\n<<< View Your Application >>>");
											System.out.println("1) Search by Application ID");
											System.out.println ("2) Search by Ic Number");
											System.out.println("3) Return to the previous page");
											boolean EH4=true;
											while (EH4)
											{
												// Exception handling 4
												try{
											System.out.print ("\nChoice (1, 2, or 3): ");
											optForView=Integer.parseInt(input.nextLine());
											EH4=false;


												}
												catch (Exception e)
												{
													System.out.println("Your input is not an Integer.Please try again");
												}
											}


											if (optForView==1)
											{
												int foundApp=0;
												String searchID;
												System.out.print("Application ID: ");
												searchID=input.nextLine ();
												for (int m=0;m<appList.size();m++)
												{
													if ((appList.get(m)).getApplicationID().equals(searchID))
													{
														(appList.get(m)).displayApplicationInfo();
														foundApp++;
													}
												}
												if (foundApp==0)
												{
													System.out.println("No application is found");
												}


											}
											else if (optForView==2)
											{
												int foundApp=0;
												String icNo;
												System.out.print("Ic Number: ");
												icNo=input.nextLine ();
												for (int m=0;m<appList.size();m++)
												{
													if (((appList.get(m)).getApplicant()).getApplicant_IcNo().equals(icNo))
													{
														(appList.get(m)).displayApplicationInfo();
														foundApp++;
													}
												}
												if (foundApp==0)
												{
													System.out.println("No application is found");
												}

											}
											else if (optForView==3)
											{
												System.out.println("Returning to the previous menu");
											}
											else
											{
												System.out.println ("Invalid input...Please try again");
											}




										}
										while (optForView!=3);// do while for view applicant's applications
					}
					else if (optApplicant==3)
					{
						System.out.println ("Returning to the previous menu");
					}
					else
					{
						System.out.println("Invalid input...Please try again");
					}

				}while (optApplicant!=3);// do while for applicant menu

			}
			else if (optCategory==2)
			{
				int selectStaff=-1;

				do
				{
					System.out.println("Please select a staff to proceed with the proceeding operations");
					for (int h=0;h<sList.size();h++)
					{
						System.out.println((h+1)+") "+(sList.get(h)).getStaff_name());
					}
					boolean EH5=true;
					while (EH5){
						// Exception handling 5
						try{
					System.out.print("\nStaff number: ");
					selectStaff=Integer.parseInt(input.nextLine());
					EH5=false;

						}
						catch (Exception e)
						{
							System.out.println("Your input is not an Integer.Please try again");
						}
					}


					if (selectStaff<1||selectStaff>(sList.size()))
					{
						System.out.println("Invalid input... Please try again");
					}
				}
				while (selectStaff<1||selectStaff>(sList.size()));

				System.out.println("\n\n");
				int optStaff=0;
				do
				{
					boolean EH6;// Exception handling 6
				displayStaffMenu ();
				do{
					EH6=true;
					try{
					optStaff=Integer.parseInt(input.nextLine());
					EH6=false;
					if (optStaff!=1&&optStaff!=2&&optStaff!=3){
						System.out.println("Invalid input... Please try again");
					System.out.print("\nYour operation: ");}
					}
					catch (Exception e){
						System.out.println("Your input is not an Integer.Please try again");
						System.out.print("\nYour operation: ");
						}
				}
				while (EH6||(optStaff!=1&&optStaff!=2&&optStaff!=3));
					switch (optStaff)
					{
					case 1:	int numPending;
							ArrayList <Integer> index=new ArrayList<Integer>();
							int numtemp=0;
							String decision,optContinue="";
							do
							{
									System.out.printf("%n%-5s%-20s%-20s%-30s%-20s%-20s%-20s%-20s%n","No","App Type","App ID","App DateTime","Name","IC No"
									,"Occupation", "Purpose");
									numPending=0;
									for (int k=0;k<appList.size();k++)
									{
										if ((appList.get(k)).getStatus()==0)
										{
											numPending++;

											String application_type;
											if (appList.get(k) instanceof Cross_district)
											{
												application_type="Cross-district";
											}
											else
											{
												application_type="Cross-state";
											}
											System.out.printf("%n%-5d%-20s%-20s%-30s%-20s%-20s%-20s%-20s%n",numPending,application_type,
											(appList.get(k)).getApplicationID(),(appList.get(k)).getApplicationDateTime(),(appList.get(k)).getApplicant().getApplicant_name()
											,(appList.get(k)).getApplicant().getApplicant_IcNo(),(appList.get(k)).getApplicant().getApplicant_job(),(appList.get(k)).getPurpose());


											index.add(k);
										}
									}
									if (numPending==0)
									{
										System.out.println("\nThere is no pending applications to be processed");

									}
									else
									{
											boolean EH7;
											do{
												EH7=true;
												// Exception handling 7
												try{
												System.out.printf("\nEnter the No of the application to be processed: ");
												numtemp=Integer.parseInt(input.nextLine());
												EH7=false;
												if (numtemp<1||numtemp>numPending)
												{
													System.out.println("The No of application is out of range....Please try again");
												}
												}
												catch (Exception e)
												{
													System.out.println("Your input is not an Integer.Please try again");
												}
											}
											while (numtemp<1||numtemp>numPending||EH7);

											(appList.get(index.get(numtemp-1))).displayApplicationInfo();
											do
											{
												System.out.println("\nDo you want to approve or reject this application");
												System.out.println("1) A for Approve\n2) R for Reject\nOr\n3) C for Cancel this operation");
												System.out.print("\nYour decision: ");
												decision=input.nextLine().toUpperCase();

												if (decision.equals("A"))
												{
													(appList.get(index.get(numtemp-1))).setStatus(1);
													(appList.get(index.get(numtemp-1))).assignedToHandler(sList.get(selectStaff-1));
													sList.get(selectStaff-1).addApplication(appList.get(index.get(numtemp-1)));
												}
												else if (decision.equals("R"))
												{
													(appList.get(index.get(numtemp-1))).setStatus(-1);
													(appList.get(index.get(numtemp-1))).assignedToHandler(sList.get(selectStaff-1));
													sList.get(selectStaff-1).addApplication(appList.get(index.get(numtemp-1)));

												}
												else if (decision.equals("C"))
												{
													System.out.println("Canceling this operation");
												}
												else
												{
													System.out.println ("Invalid input...Please try again");
												}

											}
											while (!(decision.equals("A")||decision.equals("R")||decision.equals("C")));// do while for verifying decision
											System.out.println("\nDo you still want to process another application\nPress Y if Yes\nPress N if No");
											do{
											System.out.print("\nYour choice: ");
											optContinue=input.nextLine().toUpperCase();
											if (!(optContinue.equals("Y")||optContinue.equals("N")))
											{
												System.out.println ("Invalid input...Please try again");
											}
											}
											while (!(optContinue.equals("Y")||optContinue.equals("N")));
											index.clear();
									}
							}
							while (!(optContinue.equals("N"))&&numPending>0);// do while for processing applications

							break;
					case 2: (sList.get(selectStaff-1)).displayApplicationList();
							System.out.println("\n\nPress Enter to continue...");
   							 System.in.read();
   							 input.nextLine();
							break;
					case 3:System.out.println ("Returning to the previous menu");
							break;
					default: System.out.println ("Invalid input...Please try again");
							break;
					}
				}
				while (optStaff!=3);
			}
			else if (optCategory==3)
			{
				System.out.println ("Thank you for using the program");
			}
			else
			{
				System.out.println ("Invalid input...Please try again");
			}



		}while (optCategory!=3);// do while for user category

		input.close();




	}
}