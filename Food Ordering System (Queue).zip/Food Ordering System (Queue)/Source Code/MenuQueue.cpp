#include "Node.h"
#include "MenuQueue.h"
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

MenuQueue::MenuQueue(){
      front = NULL;
      rear = NULL;
    }
    
bool MenuQueue::isEmpty(){
    	if(front==NULL && rear==NULL){
    		return true;
 		}
 		else{
 			return false;
 		}
 	}
 	
Node* MenuQueue::nodeExists(string c){
	Node * temp = NULL;
	Node * ptr = new Node;
	ptr=front;
	while (ptr != NULL){
		if (ptr->code == c){
			temp = ptr;
		}
		ptr = ptr->next;	
	}
	return temp;
}
void MenuQueue::enqueue(Node *n){
	Node* temp = nodeExists(n->code);
    if (isEmpty()){
        front = n;
        rear = n;
    }
    else if(temp!=NULL){
    	cout<<n->code<<" is exist in menu. Insertion failed. "<<endl;
    }
    
    else{
    	rear = front;
		while (rear->next != NULL){
			rear = rear->next;	
		}
      	rear->next=n;
      	rear=n;
      //top = n;
    }
}
 
void MenuQueue::dequeue(){
    Node *temp=NULL;
    if (isEmpty()){
    	cout<<"No item is available to be deleted from the food menu."<<endl;
    } 
    else{
        if(front==rear)
        {
          temp=front;
          front = NULL;
          rear = NULL;
          cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;
          delete temp;
        }
        else
        {
          temp=front;
          front = front->next;
		  cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;  
          delete temp;
        }
          
    }
}

void MenuQueue::dequeue2(string c){
	Node *temp=NULL;
    if (isEmpty()){
    	cout<<"No item is available to be deleted from the food menu."<<endl;
    } 
    else{
    	bool exist=false;
    	Node *search=front;
    	
    	while(search!=NULL&&search!=rear->next)
		{
			if (search->code==c)
			{
				exist=true;
				break;
			}
			else
			{
				search=search->next;
			}
		 }
		 if (search)
		 {
		 	
		  
        if(front==rear && front->code==c)
        {
          temp=front;
          front = NULL;
          rear = NULL;
          cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;
          delete temp;
        }
        else if (front!=rear&& front->code==c)
        {
          temp=front;
          front = front->next;
          cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;
          delete temp;
        }
        
        else{
        	Node *temp1 = front;
          	temp = front->next;
          	while (temp!=NULL){
	          	if (temp->code==c){
					temp1->next = temp->next;
	          		break;
				}
				else{
					temp1 = temp1->next;
					temp = temp->next;
				}
			}
			cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;  
          	delete temp;	
		}
    
		}
		else
		{
			cout<<"The item code is not found....."<<endl;
		}
    }	
}

void MenuQueue::updateNode(string c, double p){
	 Node* ptr = nodeExists(c);
	 if (ptr!=NULL){
	 	ptr->price = p;
	 	cout<<"Price for "<<c<< " is updated successfully"<<endl;
	 }
	 
	 else{
	 	cout<<c<<" is invalid."<<endl;
	 }
}
 
void MenuQueue::display(){
    if(isEmpty()){
        cout << "Menu is Empty" << endl;
    }
    else{
    	Node* temp = front;
		cout<<"Food Menu"<<endl;
			cout<<left<<setw(20)<<"Item ID"<<setw(40)<<"Item Name"<<setw(20)<<"Price/RM"<<endl;
		while (temp!=NULL){
			cout<<left<<setw(20)<<temp->code<<setw(40)<<temp->food<<setw(20)<<fixed<<setprecision(2)<<temp->price<<endl<<endl;
			temp = temp->next;
		}
    }
    
}

void MenuQueue::backtoFile(fstream &infile){ 
	infile.open("menu.txt",ios::out);
	Node* temp = front;
	while (temp!=NULL){
		infile<< temp->code <<"|"<< temp->food << "|"<< temp->price <<endl;
		temp = temp->next;
	}
	infile.close();
}
