#Goodness of fit test:
#H0: same happiness score for each country.
#H1: at least one country has different happiness score with others
#Testing under the significance value of 0.05

library(readxl)
X2018 <- read_excel("2018.xlsx")
View(X2018)

obs<-table(X2018$`Range Score`)
obs

alpha<-0.05
print(paste("The alpha value is: ",alpha))

x.alpha<-(qchisq(alpha,3,lower.tail=FALSE))
print(paste("The critical value is: ",x.alpha))

output <-chisq.test(obs,correct=FALSE)
output