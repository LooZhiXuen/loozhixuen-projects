#include "Item.h"
#include <iostream>
#include "Node.h"
using namespace std;

Item::Item()
{
	ID="";
	price=0;
	name="";
	quantity=0;
	next=NULL;
}
void Item::setitem(Node *food,int item_quantity )
{
	ID=food->code;
	name=food->food;
	price=food->price;
	quantity=item_quantity;	
}

double Item::getTotal(){
	return price * quantity;
}


