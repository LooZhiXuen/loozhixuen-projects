#include "Menulinkedlist.h"
#include "Node.h"
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

Menulinkedlist::Menulinkedlist(){
	head = NULL;
}

Menulinkedlist::Menulinkedlist(Node* n){
	head = n;
}

Node* Menulinkedlist::nodeExists(string c){
	Node * temp = NULL;
	Node * ptr = new Node;
	ptr=head;
	while (ptr != NULL){
		if (ptr->code == c){
			temp = ptr;
		}
		ptr = ptr->next;	
	}
	return temp;
}

void Menulinkedlist::InsertNode(Node *n){
	Node * ptr1 = new Node;
	ptr1=NULL;
	ptr1=nodeExists(n->code);
	if (ptr1 == NULL){
		Node *curr=head;
		Node *prev=NULL;
		while (curr&&n->code>curr->code)
		{
			prev=curr;
			curr=curr->next;
		}
		Node *newnode=new Node;
		newnode=n;
		if(prev==NULL)
		{
			newnode->next=head;
			head=newnode;
		}
		else
		{
			newnode->next=prev->next;
			prev->next=newnode;
		}
	}
	
	else{
		cout<<n->code<<" is exist in menu. Insertion failed. "<<endl;
	}
}

void Menulinkedlist::deleteNode(string c){
	
	if (head == NULL){
		cout<<"No item is available to be deleted from the food menu."<<endl;
	}
	
	else if (head!=NULL){
		if (head->code == c){
			Node *tempNod=new Node;
			tempNod=head;
		
			head = head->next;
			cout<<tempNod->food<<" with the code of "<<tempNod->code<<" is deleted"<<endl;
			delete tempNod;
		}
		
		else{
			Node *temp = NULL;
			Node * prevptr = head;
			Node * currentptr = head->next;
			
			while (currentptr!=NULL){
				if (currentptr->code==c){
					temp = currentptr;
					currentptr = NULL;
				}
				
				else{
					prevptr = prevptr->next;
					currentptr = currentptr->next;
				}
			}
			
			if (temp!=NULL){
				prevptr->next = temp->next;
				cout<<temp->food<<" with the code of "<<temp->code<<" is deleted"<<endl;
				delete temp;
			}
			
			else{
				cout<<"The item ID entered is invalid "<<endl;
			}
		}
	}
}

void Menulinkedlist::updateNode(string c, double p){
	 
	 Node* ptr =nodeExists(c);
	 if (ptr!=NULL){
	 	
	 	ptr->price = p;
	 	cout<<"Price for "<<c<< " is updated successfully"<<endl;
	 }
	 
	 else{
	 	cout<<c<<" is invalid."<<endl;
	 }
}

void Menulinkedlist::printList(){ 
	if (head == NULL){
		cout<< "The food menu is empty.";
	}
	
	else{
		Node* temp = head;
		cout<<"Food Menu"<<endl;
			cout<<left<<setw(20)<<"Item ID"<<setw(40)<<"Item Name"<<setw(20)<<"Price/RM"<<endl;
		while (temp!=NULL){
			cout<<left<<setw(20)<<temp->code<<setw(40)<<temp->food<<setw(20)<<fixed<<setprecision(2)<<temp->price<<endl;
			temp = temp->next;
		}
	}
}

void Menulinkedlist::backtoFile(fstream &infile){ 
	infile.open("menu.txt",ios::out);
	Node* temp = head;
	while (temp!=NULL){
		infile<< temp->code<<" "<<temp->food <<" "<<temp->price <<endl;
		temp = temp->next;
	}
	infile.close();
}

