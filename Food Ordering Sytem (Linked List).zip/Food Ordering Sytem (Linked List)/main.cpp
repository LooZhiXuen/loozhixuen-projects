#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <fstream>
#include <string>
#include "Order.h"
#include "Item.h"
#include "Customer.h"
#include "Payment.h"
#include "Customerlinkedlist.h"
#include "Itemlinkedlist.h"
#include "Node.h"
#include "Menulinkedlist.h"
using namespace std;

string user_interface = "Welcome to food ordering system. ";
string category_interface="Please choose your category.\n1. Staff\n2. Customer\n";
string customer_menu = "1 (View menu) \n2 (Place Order) \n3 (Make Payment)\n4 (Return to user menu)";
string menu_sorting = "1 (Sort ascendingly based on alphabet) \n2 (Sort descendingly based on alphabet) \n3 (Sort ascendingly based on price) \n4 (Sort descendingly based on price)";


// Inserting new item into food menu
void case1appendCode(Node * n1, Menulinkedlist *s){
	string code, food;
	bool check=false;
	double price;
	cout<<"<<<Attention>>>"<<endl;
	cout<<"No spacing is allowed for food name"<<endl;
	cout << "Enter information of item to be inserted into menu" << endl;
	cout << "Enter the code: ";
	getline(cin,code);
	do
	{
			cout << "Enter the food name: ";
	getline(cin,food);
	
	for (int j=0;food[j]!='\0';j++)
	{
		if (food[j]==' ')
		{
			cout<<"Spacing is detected...Please insert again"<<endl;
			check=true;
			break;
		}
		else
		{
			check=false;
		}
	}
	}
	while (check);

	cout << "Enter the price: RM ";
	cin >> price;
	n1 -> code = code;
	n1 -> food = food;
	n1 -> price = price;
	s->InsertNode(n1);
}
// Deleting item from the food menu
void case2deleteCode(Menulinkedlist *s){
	string code1;
	cout << "Delete Code Operation "<<endl;
	s->printList();
	cout<<endl<<"Enter code of the menu to be deleted " << endl;
	cout<<"Code: ";
	getline(cin,code1);
	s->deleteNode(code1);	
}
// Updating the price of food item
void case3updatePrice(Menulinkedlist *s){
	string code1;
	double price;
	cout << "Update Price Operation" << endl;
	s->printList();
	cout<<endl<<"Enter the food code you wanna to update: ";
	getline(cin,code1);
	cout<<endl<<"Enter the new price for "<<code1<<": ";
	cin >> price;
	s->updateNode(code1, price);
}

void AddCustomer (Customerlinkedlist *customerlist,Menulinkedlist *menu)// Adding a customer when placing a new order 
{
	string Name,tableNo;
		cout<<"Please enter your name and table number"<<endl;
			cout<<"Name: ";
			getline(cin,Name);
			cout<<"Table Number: ";
			getline(cin,tableNo);
			system("CLS");
			customerlist->addCustomer(tableNo,Name,menu);
}
void DeleteCustomer (Customerlinkedlist *customerlist)
{
	string deletename;
	cout<<"Canceling customer order can only be done with manager's permission."<<endl;
	cout<<"Customer's orders that already made payment are not allowed to be deleted"<<endl;
	cout<<"Please enter customer's' name for the order that wishes to be deleted"<<endl;
	cout<<"Customer's Name: ";
	getline(cin,deletename);
	customerlist->deleteCustomer(deletename);
	
	
}


int main(){
	
	int category;
	bool loopcategory=true;
	Customerlinkedlist *list=new Customerlinkedlist;
	Menulinkedlist *menu=new Menulinkedlist;
	fstream infile;
	cout<<user_interface<<endl<<endl;
	system ("PAUSE");
	system("CLS");
	int count=0;

	

	if (!infile)
	{
		cout<<"The input file does not exist."<<endl;
	}
	else
	{
			infile.open("menu.txt",ios::in);
	string msg;
	while (getline(infile,msg)){
		count++;	
	}
	
	infile.close();

	
	infile.open("menu.txt",ios::in);
	string code,food;
	double price;
	for(int i=0; i<count; i++){
	  	Node *add = new Node;
	  	infile>>code>>food>>price;
		add -> code = code;
	    add -> food = food;
	    add -> price = price;
	    menu->InsertNode(add);
	}

	infile.close();
	do
	{
		
	cout<<"USER MENU"<<endl;	
	cout<<"---------"<<endl;
	cout<<category_interface<<endl;
	cout<<"Or\n3. Exit program"<<endl;
	cout<<"Option: ";
	cin>>category;
	cin.ignore();
	system("CLS");
	if (category==1)
	{
		int staff_operation;
		do
		{
			cout<<"Staff Menu"<<endl;
			cout<<"----------"<<endl;
			cout<<"1. View customer's payment\n2. Cancel customer's order\n";
			cout<<"3. Modify food menu \n4. Return to user menu"<<endl;
			cout<<"Option: ";
			cin>>staff_operation;
			cin.ignore();
			system("CLS");
			if (staff_operation==1)
			{
				list->listCustomer();
				cout<<endl<<endl;
			
			}
			else if (staff_operation==2)
			{
				DeleteCustomer(list);
				cout<<endl<<endl;
	
			}
			else if (staff_operation==3)
			{
				int optionnum;
				
				 
	do{
		cout << "What operation do you want to perform? Select Option number." << endl;
		cout << "1. Insert new item into the food menu" << endl;
		cout << "2. Remove item from the food menu" << endl;
		cout << "3. Update price of item in the food menu" << endl;
		cout << "4. View updated food menu" << endl;
		cout<<"5. Exit"<<endl;

 		cout<<"Option: ";
		cin >> optionnum;
		cin.ignore();
		Node * n1 = new Node();
		//Node n1;
		system("CLS");
		switch (optionnum) {
		case 1:
			case1appendCode(n1,menu);
			break;
			
 
        case 2:
				case2deleteCode(menu);
				break;
		case 3: 
				case3updatePrice(menu);
				break;
				
    	case 4:
      		cout<< "This is the latest menu of KLW restaurant"<<endl;
      		menu->printList();
      		
 			break;
 		case 5:
 			break;
    	default:
      		cout << "Please enter the available option number. " << endl;
   		}
   		system("PAUSE");
 		system("CLS");
   } while (optionnum != 5);
   
   menu->backtoFile(infile);
			}
		
		else if (staff_operation==4)
		{
			cout<<"Returning to user menu....."<<endl;
				system("CLS");
		}
	}
	while (staff_operation!=4);
	
	
	}
	else if (category==2)
	{

		
	
	A:	
		cout<<"CUSTOMER MENU"<<endl;
		cout<<"-------------"<<endl;
		cout<<customer_menu<<endl;
		int command;
		cout<<"Insert your command: ";
		cin>>command;
		system("CLS");
		while (command == 1){
			menu->printList();

    			cout<<"Press 0 to return to customer Menu : ";
				cin>>command;
				if (command==0)
				{
					system("CLS");
					goto A;
					
				}
				
			
			system("CLS");
		}
		while (command==2)
		{
			cin.ignore();
			AddCustomer(list,menu);
			goto A;
		}
		while (command==3)
		{
				int option,index_match,operation2;
				string key;
				string tempArray[list->getlistsize()];
			V:
				cout<<"1. (Search by table number)\n2. (Search by customer's name)"<<endl;
				cout<<"Option: ";
				cin>>option;
				cin.ignore();
			if (option==1)
				{
					Customer *tempcustomer;
					cout<<"Please enter your table number"<<endl;
					cout<<"Table No: ";
					getline(cin,key);
					system("CLS");
					tempcustomer=list->searchCustomerbytable(key);
					
	
					
					if (tempcustomer==NULL)
					{
						cout<<"No result is found.\nPlease try again"<<endl;
						goto V;
					}
					else
					{
						tempcustomer->MakePayment();
						cout<<endl<<"Do you wish to"<<endl;
						cout<<"1. Make another payment"<<endl<<"2. Return to customer menu"<<endl;
						cout<<"Option: ";
						cin>>operation2;
						system("CLS");
						if (operation2==1)
						{
							goto V;
						}
						else
						{
							goto A;
						}
					}
				}
	else if (option==2)
	{
		
			cout<<"Please enter your name"<<endl;
					cout<<"Name: ";
					getline(cin,key);
					
					Customer *tempcustomer;
					tempcustomer=list->searchCustomerbyname(key);
		
					
					if (tempcustomer==NULL)
					{
						cout<<"No result is found.\nPlease try again"<<endl;
						goto V ;
					}
					else
					{
						tempcustomer->MakePayment();
						cout<<"Do you wish to"<<endl;
						cout<<"1. Make another payment"<<endl<<"2. Return to customer menu"<<endl;
						cout<<"Option: ";
						cin>>operation2;
						system("CLS");
						if (operation2==1)
						{
							goto V;
						}
						else
						{
							goto A;
						}
					}
	}
}
			if (command==4)
			{
				cout<<"Returning to user menu....."<<endl;
				system("CLS");
			}
	
}
else if (category==3)
{
	loopcategory=false;
}
else
{
	cout<<"Invalid input.....Please try again"<<endl<<endl;
	system("PAUSE");
	system("CLS");
}
}
while (loopcategory);
}
	return 0;
}

