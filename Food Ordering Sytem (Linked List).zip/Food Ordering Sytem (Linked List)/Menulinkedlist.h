#ifndef MENULINKEDLIST_H
#define MENULINKEDLIST_H
#include "Node.h"
using namespace std;


class Menulinkedlist{
	private:
		Node *head;
		
	public:
		Menulinkedlist();
		Menulinkedlist(Node *);
		Node* nodeExists (string);
		void InsertNode(Node *);
		void deleteNode (string);
		void updateNode (string, double);
		void printList();
		void backtoFile(fstream &);
};
#endif
