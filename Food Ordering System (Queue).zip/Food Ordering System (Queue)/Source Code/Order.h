#ifndef ORDER_H
#define ORDER_H
#include "ItemQueue.h"
#include "Node.h"

using namespace std;

class Order
{
	private:
	string orderId;
	int itemNo;
	ItemQueue *itemOrdered;
	public:
		Order ();
		void setID (string);
		string getOrderID();
		int getItemNo ();
		void AddItem (Node *,int);
		void RemoveItem ();
		void print ();
		double getTotalPrice ();
		
};

#endif
