#ifndef ITEMLINKEDLIST_H
#define ITEMLINKEDLIST_H
#include "Item.h"
#include "Node.h"
#include <iostream>
using namespace std;

class Itemlinkedlist
{
	private:
		Item *head;
		Item *prev;
		Item *curr;
		Item *tail;
	public:
		Itemlinkedlist ();
		~Itemlinkedlist ();
		void addItem (Node *,int);
		void deleteItem (string);
		void listitem ();
		double getTotalItemPrice ();

};
#endif



