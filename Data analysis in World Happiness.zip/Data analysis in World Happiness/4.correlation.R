#correlation

library(readxl)
X2018 <- read_excel("2018.xlsx")
View(X2018)

x<-c(X2018$`Healthy life expectancy`)
y<-c(X2018$Score)

plot(x,y,xlim=c(0,2.1),ylim=c(4,7),xlab="Health life expectancy",ylab="Score")
abline(lm(y ~ x))
cor.test(x,y)


