#include "Item.h"
#include "Itemlinkedlist.h"
#include "Node.h"
#include <iostream>
#include <iomanip>
using namespace std;

Itemlinkedlist::Itemlinkedlist()
{
	head=NULL;
	prev=NULL;
	curr=NULL;
	tail=NULL;
}
Itemlinkedlist::~Itemlinkedlist()
{
		while(head!=NULL){
				curr=head;
				head=head->next;
				delete head;
			}
}
void Itemlinkedlist::addItem(Node *food,int quantity)
{
	 Item *newitem = new Item;     
		newitem->setitem(food,quantity);
		    if (head == NULL)// checking whether item is the first to be added
		    {
		        head = newitem;
		        tail = newitem;
		    }
		    else 
		    {
		        tail->next = newitem; 
		        tail = newitem; 
		    }
}

void Itemlinkedlist::deleteItem(string id)
{
		curr=head;
			// Search the item to be deleted
			while ((curr != NULL) && (curr->ID != id)){    
	         	prev = curr; 
	         	curr = curr->next;
   	  		}
   	  		if (curr == NULL)
         		cout << "No item can be deleted from the order" << endl;
		     else{

		         if (curr == head) // deletion on the head
		         {
		             head = curr->next;
		             delete curr;                         
		         }
		         else if (curr == tail) // deletion on the tail
		         {
		             tail = prev;
		             tail->next = NULL;
		             delete curr;              
		         }         
		         else // item deletion in a middle of 2 nodes
		         {
		             prev->next = curr->next;
		             delete curr;
		         }
	
		     
		   	}
}
void Itemlinkedlist::listitem()
{
	int num=0;
		curr=head;
			while(curr!=NULL){
					cout<<left<<setw(10)<<num+1<<setw(20)<<curr->ID<<setw(40)<<curr->name;
					cout<<left<<setw(20)<<fixed<<setprecision(2)<<curr->price<<setw(20)<<curr->quantity;
					cout<<left<<setw(20)<<fixed<<setprecision(2)<<curr->getTotal()<<endl;
					curr=curr->next;
		
					num++;
				}

}
double Itemlinkedlist::getTotalItemPrice()
{
	curr=head;
	double total=0;

	while (curr!=NULL)
	{
		total=total+curr->getTotal();
		curr=curr->next;
	}

	return total;
}

