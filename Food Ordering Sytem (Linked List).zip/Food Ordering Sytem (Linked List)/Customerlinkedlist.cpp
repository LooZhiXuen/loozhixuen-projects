#include "Customerlinkedlist.h"
#include "Menulinkedlist.h"
#include "Customer.h"
#include <iostream>
#include <iomanip>
using namespace std;

Customerlinkedlist::Customerlinkedlist()
{
	head=NULL;
	prev=NULL;
	curr=NULL;
	tail=NULL;
}
Customerlinkedlist::~Customerlinkedlist()
{
		while(head!=NULL){
				curr=head;
				head=head->next;
				delete head;
			}
}
void Customerlinkedlist::addCustomer(string tableno,string name,Menulinkedlist *menu)
{
	   Customer *newcustomer = new Customer;     
		   newcustomer->set(tableno,name);// set customer's table number and name
		   newcustomer->PlaceOrder(menu);// invoke operations of adding and removing items from customer's order 
		    if (head == NULL)// checking whether customer is the first to be added
		    {
		        head = newcustomer;
		        tail = newcustomer;
		    }
		    else 
		    {
		        tail->next = newcustomer; 
		        tail = newcustomer; 
		    }
}

void Customerlinkedlist::deleteCustomer(string name)
{

			curr=head;
			// Search the customer to be deleted
			while ((curr != NULL) && (curr->Name != name)){    
	         	prev = curr; 
	         	curr = curr->next;
   	  		}
   	  		if (curr == NULL)
         		cout << "No customer's order to be canceled....'" << endl;
		     else{
		     	if (curr->bill.getStatus())
		     	{
		     		cout<<"Payment has been made for this customer's order'. This order cannot be canceled."<<endl;
				 }
				 else
				 {
				 	
				 
		         if (curr == head) // deletion on the head
		         {
		             head = curr->next;
		             delete curr;                         
		         }
		         else if (curr == tail) // deletion on the tail
		         {
		             tail = prev;
		             tail->next = NULL;
		             delete curr;              
		         }         
		         else // item deletion in a middle of 2 nodes
		         {
		             prev->next = curr->next;
		             delete curr;
		         }
		         cout<<"The order is canceled successfully."<<endl;
		     }
		   	}
}
Customer* Customerlinkedlist::searchCustomerbytable(string tablenum)
{
		curr=head;
			while(curr!=NULL&&curr->tableNo!=tablenum){
				curr=curr->next;
			}
			return curr;
}
Customer* Customerlinkedlist::searchCustomerbyname(string nama)
{
		curr=head;
			while(curr!=NULL&&curr->Name!=nama){
				curr=curr->next;
			}
			return curr;
}
void Customerlinkedlist::listCustomer()
{
	curr=head;
	if (curr==NULL)
	{
			cout<<"There is no customer yet."<<endl;
	}
	else
	{
		cout<<left<<setw(20)<<"Table Number"<<setw(40)<<"Customer's Name"<<setw(20)<<"Total Amount/RM"<<setw(20)<<"Cash/RM"<<setw(20)<<"Change/RM"<<setw(10)<<"Status"<<endl;
			while(curr!=NULL){
					curr->printPaymentinfo();
					curr=curr->next;
				}
	}
}
int Customerlinkedlist::getlistsize()// Returning the size of linked list
{
	int num=0;
	curr=head;
	while (curr!=NULL)
	{
		curr=curr->next;
		num++;
	}
	return num;
}
