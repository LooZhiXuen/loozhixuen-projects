#ifndef ITEMQUEUE_H
#define ITEMQUEUE_H
#include "Item.h"
#include "Node.h"
#include <iostream>
using namespace std;

class ItemQueue
{
	private:
		Item *front;
		Item *rear;
	public:
		ItemQueue ();
		bool isEmpty();
		void addItem_Queue (Node *,int);
		void deleteItem_Queue ();
		void listitem ();
		double getTotalItemPrice ();

};
#endif



