<?php
require_once('../config/setting.php');
require_once('../config/function.php');
require_once('../config/db.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
.yes{
  background-color:lightgreen;
  width:80px;
  height:50px;
}
.yes:hover{
  background-color:green;
}
.no{
  background-color:red;
  width:80px;
  height:50px;
}
.no:hover{
  background-color:darkred;
}
</style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>KnightOne Bootstrap Template - Index</title>
  <meta content="" name="tbl_list_Description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: KnightOne - v4.3.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages ">
    <div class="container-fluid">

      <div class="row justify-content-center" style="padding-top:20px;padding-bottom:20px">
        <div class="col-xl-9 d-flex align-items-center justify-content-lg-between">
          <h1 class="logo me-auto me-lg-0"><a href="adminIndex.php">ITSenSei</a></h1>
        </div>
      </div>

    </div>
  </header><!-- End Header -->



  <main id="main">

  <section id="features" class="features">
      <div class="container">
      <div class="section-title">
          <h2>Delete Mission</h2>

        </div>
        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1">
            <div class="icon-box mt-5 mt-lg-0">
<?php

if(!isset($_POST['choice']))
{
       $u=$_GET['tbl_list_Goal'];
       $sql ="select * from tbl_list where tbl_list_Goal='".$u."'";  // sql command
       mysqli_select_db($conn,$database); ///select database as default
       $result=mysqli_query($conn,$sql);  // command allow sql cmd to be sent to mysql
       $row=mysqli_fetch_assoc($result);
       ?>

  <form action="deletelist.php?tbl_list_Goal=<?php echo $u; ?>" method="POST">
  <label for="Goal">Mission:</label>
  <input type="text" disabled id="tbl_list_Goal" name="tbl_list_Goal" value="<?php echo $u; ?>  "><br><br>
  <label for="desc">Description:</label>
  <input type="text" style="width:500px;"disabled id="desc" name="desc" value="<?php echo $row['tbl_list_Description'];?>"><br><br>
  <p>Are you sure you want to delete this record?</p>
  <p><input class="yes" type="submit" value="Yes" name="choice"><input class="no" type="submit" value="No" name="choice"></p>
  </form>

<?php }
else{
if (isset($_POST['choice'])){
       if($_POST['choice']=='Yes')
       {
        $u=$_GET['tbl_list_Goal'];
        $sql ="DELETE FROM `tbl_list`
        WHERE (`tbl_list_Goal`='".$u."')";  // sql command
        echo $sql;
        mysqli_select_db($conn,"wpproject"); ///select database as default
        $result=mysqli_query($conn,$sql);  // command allow sql cmd to be sent to mysql
       // mysqli_fetch_assoc($result);
       goto2("viewlist.php"," tbl_list_Goal is successfully deleted");
       }
       else
       {   $to="viewlist.php";
       echo ("<script>location.href='$to'</script>");
       }
}
}

?>
</div>
</div>
      </div>
      </div>
    </section><!-- End Features Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3>KnightOne</h3>
      <p>Et aut eum quis fuga eos sunt ipsa nihil. Labore corporis magni eligendi fuga maxime saepe commodi placeat.</p>
      <div class="copyright">
        &copy; Copyright <strong><span>KnightOne</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 <!-- Vendor JS Files -->
 <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
</body>

</html>