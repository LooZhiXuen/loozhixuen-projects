#include "Item.h"
#include "ItemQueue.h"
#include "Node.h"
#include <iostream>
#include <iomanip>
using namespace std;

ItemQueue::ItemQueue()
{
	front=NULL;
	rear=NULL;
}
bool ItemQueue::isEmpty()
{
	if (front==NULL&&rear==NULL)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void ItemQueue::addItem_Queue(Node *food,int quantity)
{
	 Item *newitem = new Item;     
		newitem->setitem(food,quantity);
		if (isEmpty())
		{
			front=newitem;
			rear=newitem;
		}
		else
		{
			rear->next=newitem;
			rear=newitem;
		}
}

void ItemQueue::deleteItem_Queue()
{
		Item *delItem=new Item;
			// Search the item to be deleted
		if (isEmpty())
		{
			cout<<"No item is available to be removed from the order list"<<endl;
			
		}
		else
		{
		
			delItem=front;
			front=front->next;
			delItem->next=NULL;
			delete delItem;
			cout<<"The first item added to the order list has been removed successfully"<<endl;
		}
}
void ItemQueue::listitem()
{
	int num=0;
	Item *temp;
		temp=front;
			while(temp!=NULL){
					cout<<left<<setw(10)<<num+1<<setw(20)<<temp->ID<<setw(40)<<temp->name;
					cout<<left<<setw(20)<<fixed<<setprecision(2)<<temp->price<<setw(20)<<temp->quantity;
					cout<<left<<setw(20)<<fixed<<setprecision(2)<<temp->getTotal()<<endl;
					temp=temp->next;
		
					num++;
				}

}
double ItemQueue::getTotalItemPrice()
{
	Item *temp;
	temp=front;
	double total=0;

	while (temp!=NULL)
	{
		total=total+temp->getTotal();
		temp=temp->next;
	}

	return total;
}

