#ifndef MENUQUEUE_H
#define MENUQUEUE_H
#include "Node.h"
using namespace std;

class MenuQueue
{
	public:
  	Node *front;
  	Node *rear;
  	MenuQueue ();
  	bool isEmpty ();
  	Node *nodeExists (string);
  	void enqueue(Node *); 
  	void dequeue();
  	void dequeue2(string );
  	void updateNode(string , double );
  	void display();
  	void backtoFile(fstream &infile);

};
#endif
