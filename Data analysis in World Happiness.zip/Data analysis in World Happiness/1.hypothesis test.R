#x1="Mean of happiness score of Asia countries in 2018"
#x2="Mean of happiness score of Europe countries in 2018"
#H0: x1-x2=0
#H1: x1-x2!=0

#Assuming variance is different
#Testing under the significance levelS of 0.05

library(readxl)
asia <- read_excel("asia.xlsx")
View(asia)

library(readxl)
europe <- read_excel("europe.xlsx")
View(europe)

xbar1<-mean(asia$Score)
print(paste("The mean of happiness score in Asia is: ",xbar1))

xbar2<-mean(europe$Score)
print(paste("The mean of happiness score in Europe is: ",xbar2))

s1<-sd(asia$Score)
print(paste("The standard deviation of happiness score in Asia is: ",s1))

s2<-sd(europe$Score)
print(paste("The standard deviation of happiness score in Europe is: ",s2))

n1<-nrow(asia)
print(paste("The number of countries from Asia in this data is: ",n1))

n2<-nrow(europe)
print(paste("The number of countries from Europe in this data is: ",n2))

v<-((s1^2/n1)+(s2^2/n2))^2/(((s1^2/n1)^2/(n1-1))+((s2^2/n2)^2/(n2-1)))
print(paste("The degree of freedom is: ",v))

t0<-(xbar1-xbar2-0)/(sqrt((s1^2/n1)+(s2^2/n2)))
print(paste("The test statistic is: ",t0))

pvalue<-pt(t0,floor(v))
print(paste("The P-value is: ",pvalue))

alpha<-0.05
print(paste("The alpha value is: ",alpha))

t.alpha = qt(alpha/2,floor(v))
print(paste("The critical value is: ",t.alpha))




