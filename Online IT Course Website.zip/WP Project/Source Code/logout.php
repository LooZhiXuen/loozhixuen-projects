<?php
    require_once('config/function.php');
   
    session_start();
    unset($_SESSION['userid']);
    unset($_SESSION['password']);
    unset($_SESSION['Email']);
    unset($_SESSION['Name']);
    session_destroy();

 
  goto2("login.php","You have log out from the Portal")




?>