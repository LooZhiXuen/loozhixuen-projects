#ifndef _ITEM_H_
#define _ITEM_H_

#include <string>
#include "Node.h"
using namespace std;

class Item{

	public: 
	
		string ID;
		string name;
		double price;
		int quantity;
		Item *next;
		Item ();
		void setitem (Node *,int);
		double getTotal();	
};

#endif

