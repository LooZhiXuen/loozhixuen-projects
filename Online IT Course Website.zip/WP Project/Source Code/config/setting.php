<?php

$projectname="Knight One";
$servername="localhost";
$user="root";
$passw="";
$portno="3306";
$database='wpproject';



?>