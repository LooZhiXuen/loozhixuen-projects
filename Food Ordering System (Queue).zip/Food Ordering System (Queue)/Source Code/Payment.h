#ifndef PAYMENT_H
#define PAYMENT_H

using namespace std;

class Payment 
{
	private :
		double cash;
		double change;
		bool status;
	public:
		Payment ();
		void set (double,double);
		bool getStatus();
		double getCash();
		double getChange ();
		void print ();
	
};

#endif

